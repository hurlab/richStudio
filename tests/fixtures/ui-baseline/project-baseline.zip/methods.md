# Methods summary

Generated from the project manifest. Only recorded parameters are stated as facts.

## Recorded facts

- richStudio 0.1.6 with richR 0.1.5 on R version 4.6.2 (2026-10-29).

## Display labels (names chosen by the user, not parameters)

- deg_mouse1
- deg_mouse2
- deg_mouse3
- go1
- go2
- kegg1
- clus1

## Unavailable provenance

- Enrichment go1: run parameters.
- Enrichment go1: background identity.
- Enrichment go1: multiple-testing correction method.
- Enrichment go1: annotation provider, release, build and digest.
- Enrichment go2: run parameters.
- Enrichment go2: background identity.
- Enrichment go2: multiple-testing correction method.
- Enrichment go2: annotation provider, release, build and digest.
- Enrichment kegg1: run parameters.
- Enrichment kegg1: background identity.
- Enrichment kegg1: multiple-testing correction method.
- Enrichment kegg1: annotation provider, release, build and digest.
- Clustering clus1: method and parameters.

